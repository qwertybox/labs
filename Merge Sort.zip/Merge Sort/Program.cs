﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Merge_Sort
{
    class Program
    {
        private static List<int> MergeSort(List<int> unsorted)
        {
            if (unsorted.Count <= 1) // Тобто якщо ми доділили масив до 1-чних підмасивів, то логічно що більше ділити масив не можна, а відтак якщо не зробити вихід з цієї процедури виникне помилка переповнення буферу.
            {
                return unsorted;
            }

            List<int> left = new List<int>(); // створюємо лівий та правий підмасиви.
            List<int> right = new List<int>();
            int m = unsorted.Count / 2;
            for (int k = 0; k < m; k++) // ініціалізуємо лівий та правий масиви.
            {
                left.Add(unsorted[k]);
            }
            for (int k = m; k < unsorted.Count; k++)
            {
                right.Add(unsorted[k]);
            }
            left = MergeSort(left); // викликаємо цю ж процедуру для лівого та правого підмасиву
            right = MergeSort(right);
            return Merge(left, right); // викликаємо метод Merge і повертаємо його як результат виконання поточного методу
        }

        private static List<int> Merge(List<int> left, List<int> right)
        {
            List<int> result = new List<int>();

            while (left.Count > 0 || right.Count > 0) // цикл викониється доти, поки хоча б один зі списків містить хоча б 1 елемент.
            {
                if (left.Count > 0 && right.Count > 0)
                {
                    if (left.First() <= right.First())  //Порівнюємо елементи списків (у даній програмі краще використовувати список, ніж масив, щоб було легше додавати та прибирати елементи) 
                    {
                        result.Add(left.First()); // додаємо елемент до результату
                        left.Remove(left.First());      //прибираємо елемент з лівого списку
                    }
                    else
                    {
                        result.Add(right.First());
                        right.Remove(right.First());
                    }
                }
                else if (left.Count > 0)
                {
                    result.Add(left.First());
                    left.Remove(left.First());
                }
                else if (right.Count > 0)
                {
                    result.Add(right.First());

                    right.Remove(right.First());
                }
            }
            return result; // повертаємо результат
        }

        public static int[] SelectionSort(int[] arr, int n)
        {
            int temp, smallest;
            for (int i = 0; i < n - 1; i++)
            {
                smallest = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (arr[j] < arr[smallest])
                    {
                        smallest = j;
                    }
                }
                temp = arr[smallest];
                arr[smallest] = arr[i];
                arr[i] = temp;
            }
            return arr;
        }

        static void Main(string[] args)
        {
            List<int> unsorted = new List<int>() { 8, 9, 3, 2, 1, 6, 0 };
            List<int> sorted;
            Console.Write("Початковий масив: " + " ");
            foreach (int el in unsorted)
            {
                Console.Write(el + " ");
            }
            Console.WriteLine();
            sorted = MergeSort(unsorted);
            Console.Write("Відсортований масив: " + " ");
            foreach (int el in sorted)
            {
                Console.Write(el + " ");
            }
            Console.WriteLine();
            int[] arrr = SelectionSort(unsorted.ToArray(), unsorted.Count);
            Console.Write("Відсортований масив: " + " ");
            foreach (int el in arrr)
            {
                Console.Write(el + " ");
            }
            Console.ReadKey();
        }
    }

    
}
