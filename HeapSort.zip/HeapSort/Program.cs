﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapSort
{
    class Program
    {      
        static void Main(string[] args)
        {
            int[] arr = { 22,1,1,4,5,0 };
            int n = arr.Length;
            //Console.WriteLine(n);
            HeapSort ob = new HeapSort();
            ob.sort(arr);

            Console.WriteLine("Sorted array is");
            HeapSort.printArray(arr);
        }
    }
}
